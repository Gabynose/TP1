#include <stdio.h>
#include <stdbool.h>
/* ESTAS CONSTANTES SON PARA LAS PREGUNTAS QUE NECESITAN UNA RESPUESTA MULTIPLE CHOICE DE A, B, C o D */
const char LETRA_VALIDA_1 = 'A';
const char LETRA_VALIDA_2 = 'B';
const char LETRA_VALIDA_3 = 'C';
const char LETRA_VALIDA_4 = 'D';
/*ESTA CONSTANTE ES PARA EL VECTOR DEL PUNTO 3*/
const int ITEMS_MAXIMOS = 5;
const int EXCEPCION_1 = 1;
const int EXCEPCION_2 = 2;
/* EN ESTA PARTE PONGO LAS CONSTANTES QUE SERIAN LAS RESPUESTAS CORRECTAS DE LAS PREGUNTAS */
const char RESPUESTA_VALIDA_MONSTERS = 'A';
const char RESPUESTA_VALIDA_LILO = 'C';
const int RESPUESTA_VALIDA_TADASHI = 0;
const int RESPUESTA_VALIDA_CARS = 95;
const char RESPUESTA_VALIDA_ALADDIN = 'C';

/* LETRAS DE LA CONTRASENIA */
const char LETRA_REVELADA_VALIDA_1 = 'K'; /* Se revela si PREGUNTA 1 es correcta */
const char LETRA_REVELADA_VALIDA_2 = 'R'; /* Se revela si PREGUNTA 2 es correcta */
const char LETRA_REVELADA_VALIDA_3 = 'O'; /* Se revela si PREGUNTA 3 es correcta */
const char LETRA_REVELADA_VALIDA_4 = 'N'; /* Se revela si PREGUNTA 4 es correcta */
const char LETRA_REVELADA_VALIDA_5 = 'O'; /* Se revela si PREGUNTA 3 es correcta */
const char LETRA_REVELADA_VALIDA_6 = 'S'; /* Se revela si PREGUNTA 5 es correcta */
const char LETRA_REVELADA_INVALIDA = 'X'; /* Se revela si cualquier PREGUNTA es incorrecta */
const int ITEMS_MAX_CONTRASENIA = 6;

/* REINGRESAR DATOS */
//PRE: 
//POST: devuelve una condicion para pedir el reingreso de la respuesta al usuario.
char condicion_caracter_ingresado(char* respuesta_correcta_1){
	char condicion_caracter = (*respuesta_correcta_1 != LETRA_VALIDA_1 && *respuesta_correcta_1 != LETRA_VALIDA_2 && *respuesta_correcta_1 != LETRA_VALIDA_3 && *respuesta_correcta_1 != LETRA_VALIDA_4);
	return condicion_caracter;
}
//PRE: 
//POST: devuelve 0 si el parametro no es primo o devuelve 1 si el parametro es primo.
int es_primo(int numero){
	if (numero <= 1){
		return 0;
	}else if (numero == 2){
		return 1;
	}else{
		for (int i = 2; i < numero; i++){
			if (numero % i == 0){
				return 0;
			}
		}
		return 1; 
	}
}
//PRE: 
//POST: devuelve la condicion para verificar si los numeros del vector respuesta_ingresada_3 son primos o no.
int condicion_es_primo (int* respuesta_ingresada_3){
	int condicion = es_primo(respuesta_ingresada_3[0]) && es_primo(respuesta_ingresada_3[1]) && es_primo(respuesta_ingresada_3[2]) && es_primo(respuesta_ingresada_3[3]) && es_primo(respuesta_ingresada_3[4]);
	return condicion;
}

/* PROCEDIMIENTOS DE IMPRESION E INGRESO DE DATOS POR EL USUARIO */
//PRE: 
//POST: respuesta_ingresada_1 va a ser unicamente 'A', 'B', 'C', 'D', en mayusculas
void imprimir_pregunta_y_pedir_respuesta_monsters(char* respuesta_ingresada_1){
	printf ("Pregunta 1. ¿Cual es el codigo de emergencia utilizado en Monsters Inc. cuando uno de los personajes tiene una media humana pegada a su cuerpo? \n");
	printf ("(A) 3312. \n(B) 3317. \n(C) 2312. \n(D) 2031. \n");
	scanf(" %c", respuesta_ingresada_1);
	// Si se ingresa un caracter distinto a los permitidos, se pide un reingreso de la respuesta // 
	while (condicion_caracter_ingresado(respuesta_ingresada_1)){
		printf("Porfavor reingrese una respuesta valida, recuerde que su respuesta tiene que ser A, B, C o D con las mayusculas activas. \n");
		printf ("Pregunta 1. ¿Cual es el codigo de emergencia utilizado en Monsters Inc. cuando uno de los personajes tiene una media humana pegada a su cuerpo? \n");
		printf ("(A) 3312. \n(B) 3317. \n(C) 2312. \n(D) 2031. \n");
		scanf(" %c", respuesta_ingresada_1);
	}
}
//PRE: 
//POST: respuesta_ingresada_2 tiene que ser unicamente 'A', 'B', 'C', 'D', en mayusculas.
void imprimir_pregunta_y_pedir_respuesta_lilo(char* respuesta_ingresada_2){
	printf("Pregunta 2. ¿Cual era el nombre del pez mascota de Lilo? \n");
	printf("(A) Stich. \n(B) Pez. \n(C) Pato. \n(D) Aurelio.\n");
	scanf(" %c", respuesta_ingresada_2);
	// Si se ingresa un caracter distinto a los permitidos, se pide un reingreso de la respuesta // 
	while (condicion_caracter_ingresado(respuesta_ingresada_2)){
		printf("Porfavor reingrese una respuesta valida, recuerde que su respuesta tiene que ser A, B, C o D con las mayusculas activas. \n");
		printf("Pregunta 2. ¿Cual era el nombre del pez mascota de Lilo? \n");
		printf("(A) Stich. \n(B) Pez. \n(C) Pato. \n(D) Aurelio.\n");
		scanf(" %c", respuesta_ingresada_2);
	}
}
//PRE: 
//POST: respuesta_ingresada_3 es un vector que recibe 5 numeros, cada numero tiene que ser entero y estar entre 1 y 100.
void imprimir_pregunta_y_pedir_respuesta_tadashi(int respuesta_ingresada_3[ITEMS_MAXIMOS]){ 

	for (int i = 0; i < ITEMS_MAXIMOS; i++){
		printf ("Pregunta 3. Tadashi necesita que lo ayudes con unos calculos.\n");
		printf("Ingrese 5 numeros, todos deben ser primos y que esten entre 1 y 100: ");
		scanf("%i", &respuesta_ingresada_3[i]);
		// Si se ingresa un numero fuera del rango permitido, se pide un reingreso de la respuesta //
		while (respuesta_ingresada_3[i] < 1 || respuesta_ingresada_3[i] > 100){
			printf("Porfavor reingrese un numero dentro del rango valido.\n");
			printf("Pregunta 3. Tadashi necesita que lo ayudes con unos calculos. \n");
			printf("Ingrese 5 numeros, todos deben ser primos y que esten entre 1 y 100: ");
			scanf("%i", &respuesta_ingresada_3[i]);
		}
	}

}
//PRE: 
//POST: respuesta_ingresada_4 tiene que ser unicamente un valor entero entre 1 y 100.
void imprimir_pregunta_y_pedir_respuesta_cars(int* respuesta_ingresada_4){
	printf("Pregunta 4. Que numero lleva el rayo McQueen? \n");
	printf("Ingrese un valor del 1 al 100: \n");
	scanf("%i", respuesta_ingresada_4);
	// Si se ingresa un numero fuera del rango permitido, se pide un reingreso de la respuesta // 
	while(*respuesta_ingresada_4 < 1 || *respuesta_ingresada_4 > 100){
		printf("Su respuesta esta fuera del rango solicitado. \n");
		printf("Pregunta 4. Que numero lleva el rayo McQueen? \n");
		printf("Ingrese un valor del 1 al 100: \n");
		scanf("%i", respuesta_ingresada_4);

	}
}
//PRE: 
//POST: respuesta_ingresada_1 tiene que ser unicamente 'A', 'B', 'C', 'D', en mayusculas.
void imprimir_pregunta_y_pedir_respuesta_aladdin(char* respuesta_ingresada_5){
	printf("Pregunta 5. ¿Como se llama el tigre de la princesa Jazmin?\n");
	printf("(A) Zafiro. \n(B) Abu. \n(C) Rajah. \n(D) Jafar.\n");
	scanf(" %c", respuesta_ingresada_5);
	// Si se ingresa un caracter distinto a los permitidos, se pide un reingreso de la respuesta //
	while (condicion_caracter_ingresado(respuesta_ingresada_5)){
		printf("Porfavor reingrese una respuesta valida, recuerde que su respuesta tiene que ser A, B, C o D con las mayusculas activas. \n");
		printf("Pregunta 5. ¿Como se llama el tigre de la princesa Jazmin?\n");
		printf("(A) Zafiro. \n(B) Abu. \n(C) Rajah. \n(D) Jafar.\n");
		scanf(" %c", respuesta_ingresada_5);
	}
}

/* REVELACION DE CONTRASENIA */
//PRE: 
//POST: si respuesta_ingresada_1 es igual a RESPUESTA_VALIDA_MONSTERS se le asigna a la primer posicion de contrasenia la letra 'K', sino se le asigna la letra 'X'.
void comprobar_respuesta_correcta_pregunta_monsters(char contrasenia[ITEMS_MAX_CONTRASENIA], char respuesta_ingresada_1){
	if (respuesta_ingresada_1 == RESPUESTA_VALIDA_MONSTERS){
		contrasenia [0] = LETRA_REVELADA_VALIDA_1;
	}else{
		contrasenia [0] = LETRA_REVELADA_INVALIDA;
	}
}
//PRE:
//POST: si respuesta_ingresada_2 es igual a RESPUESTA_VALIDA_LILO se le asigna a la segunda posicion de contrasenia la letra 'R', sino se le asigna la letra 'X'.
void comprobar_respuesta_correcta_pregunta_lilo(char contrasenia[ITEMS_MAX_CONTRASENIA], char respuesta_ingresada_2){
	if (respuesta_ingresada_2 == RESPUESTA_VALIDA_LILO){
		contrasenia [1] = LETRA_REVELADA_VALIDA_2;
	}else{
		contrasenia [1] = LETRA_REVELADA_INVALIDA;
	}
}
//PRE:
//POST: si se cumple la condicion de los primos de cada numero del vector respuesta_ingresada_3 entonces a la tercer posicion de contrasenia y a la quinta posicion de contrasenia se les asigna la letra 'O', sino se les asigna la letra 'X'.
void comprobar_respuesta_correcta_pregunta_tadashi(char contrasenia[ITEMS_MAX_CONTRASENIA], int respuesta_ingresada_3[ITEMS_MAXIMOS]){
	if (condicion_es_primo(respuesta_ingresada_3)){
		contrasenia[2] = LETRA_REVELADA_VALIDA_3;
		contrasenia[4] =  LETRA_REVELADA_VALIDA_5;
	}else{
		contrasenia [2] = LETRA_REVELADA_INVALIDA;
		contrasenia [4] = LETRA_REVELADA_INVALIDA;
	}
}
//PRE:
//POST: si respuesta_ingresada_4 es igual a RESPUESTA_VALIDA_CARS se le asigna a la cuarta posicion de contrasenia la letra 'N', sino se le asigna la letra 'X'.
void comprobar_respuesta_correcta_pregunta_cars(char contrasenia[ITEMS_MAX_CONTRASENIA], int respuesta_ingresada_4){
	if (respuesta_ingresada_4 == RESPUESTA_VALIDA_CARS){
		contrasenia[3] = LETRA_REVELADA_VALIDA_4;
	}else{
		contrasenia[3] = LETRA_REVELADA_INVALIDA;
	}
}
//PRE: 
//POST: si respuesta_ingresada_5 es igual a RESPUESTA_VALIDA_ALADIN se le asgina a la sexta posicion de contrasenia la letra 'S', sino se le asigna la letra 'X'
void comprobar_respuesta_correcta_pregunta_aladdin(char contrasenia[ITEMS_MAX_CONTRASENIA], int respuesta_ingresada_5){
	if (respuesta_ingresada_5 == RESPUESTA_VALIDA_ALADDIN){
		contrasenia[5] = LETRA_REVELADA_VALIDA_6;
	}else{
		contrasenia[5] = LETRA_REVELADA_INVALIDA;
	}
}
//PRE: 
//POST: se revela cada letra del vector contrasenia con un '-' al inicio y al final.
void revelar_contrasenia(char* contrasenia){
	printf("-");
	for (int i = 0; i < ITEMS_MAX_CONTRASENIA; i++){
		printf("%c", contrasenia[i]);
	}
	printf("-\n");
}

int main(){
	/* VARIABLES */
	char respuesta_ingresada_1;
	char respuesta_ingresada_2;
	int respuesta_ingresada_3[ITEMS_MAXIMOS];
	int respuesta_ingresada_4;
	char respuesta_ingresada_5;
	char contrasenia [ITEMS_MAX_CONTRASENIA]; /* Aca se revelan las letras de la contrasenia*/

	//* PREGUNTA 1 //*
	imprimir_pregunta_y_pedir_respuesta_monsters(&respuesta_ingresada_1);
	
	//* PREGUNTA 2 //*
	imprimir_pregunta_y_pedir_respuesta_lilo(&respuesta_ingresada_2);

	//* PREGUNTA 3 //*
	imprimir_pregunta_y_pedir_respuesta_tadashi(respuesta_ingresada_3);

	//* PREGUNTA 4 //*
	imprimir_pregunta_y_pedir_respuesta_cars(&respuesta_ingresada_4);
		
	//* PREGUNTA 5 //*
	imprimir_pregunta_y_pedir_respuesta_aladdin(&respuesta_ingresada_5);
	
	//* REVELACION DE CONTRASENIA *//
	comprobar_respuesta_correcta_pregunta_monsters(contrasenia, respuesta_ingresada_1);
	comprobar_respuesta_correcta_pregunta_lilo(contrasenia, respuesta_ingresada_2);
	comprobar_respuesta_correcta_pregunta_tadashi(contrasenia, respuesta_ingresada_3);
	comprobar_respuesta_correcta_pregunta_cars(contrasenia, respuesta_ingresada_4);
	comprobar_respuesta_correcta_pregunta_aladdin(contrasenia, respuesta_ingresada_5);
	revelar_contrasenia(contrasenia);
	
	return 0;

}

